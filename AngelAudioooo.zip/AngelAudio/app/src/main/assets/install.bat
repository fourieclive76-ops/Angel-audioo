@echo off
title Angel Audio Setup
set "HUB=__HUB_IP__"
set "DIR=%LOCALAPPDATA%\AngelAudio"
if not exist "%DIR%" mkdir "%DIR%"
echo Downloading Angel Audio from your phone...
curl -s -f -o "%DIR%\angel_audio_sender.py" http://%HUB%:8080/angel_audio_sender.py
if errorlevel 1 (
  echo Could not reach the phone. Is USB tethering on and Angel Audio started?
  pause
  exit /b 1
)
where py >nul 2>nul
if errorlevel 1 (
  where winget >nul 2>nul
  if errorlevel 1 (
    echo Please install Python from python.org and tick Add Python to PATH. Then open this file again.
    start https://www.python.org/downloads/
    pause
    exit /b 1
  )
  echo Installing Python, one time only. Please wait...
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  echo.
  echo Python is installed. Please double-click this setup file once more to finish.
  pause
  exit /b 0
)
echo Installing audio components...
py -m pip install --quiet --disable-pip-version-check soundcard "numpy<2"
echo @echo off> "%DIR%\Angel Audio.bat"
echo py "%DIR%\angel_audio_sender.py">> "%DIR%\Angel Audio.bat"
copy /y "%DIR%\Angel Audio.bat" "%USERPROFILE%\Desktop\Angel Audio.bat" >nul
echo.
echo Done. A shortcut called Angel Audio is now on your Desktop.
echo Starting Angel Audio now. Leave this window open while you listen.
py "%DIR%\angel_audio_sender.py"
pause
