#!/bin/bash
# Angel Audio setup for Linux (Mac needs a loopback device such as BlackHole)
DIR="$HOME/.angelaudio"; mkdir -p "$DIR"
curl -sf -o "$DIR/angel_audio_sender.py" http://__HUB_IP__:8080/angel_audio_sender.py || { echo "Cannot reach the phone"; exit 1; }
python3 -m pip install --user --quiet soundcard "numpy<2"
echo "Starting Angel Audio..."
python3 "$DIR/angel_audio_sender.py"
