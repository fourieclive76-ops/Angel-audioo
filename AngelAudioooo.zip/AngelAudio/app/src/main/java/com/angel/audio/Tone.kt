package com.angel.audio

import android.media.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

/** One second 440 Hz beep. Used by the Test button and when the main phone asks this phone to identify itself. */
suspend fun playTestTone(gain: Float) = withContext(Dispatchers.IO) {
    val rate = 48000
    val n = rate
    val data = ShortArray(n) { i ->
        val env = when { i < 2400 -> i / 2400f; i > n - 2400 -> (n - i) / 2400f; else -> 1f }
        val v = (sin(2 * PI * 440 * i / rate).toFloat() * 0.4f * gain * env).coerceIn(-1f, 1f)
        (v * 32767).toInt().toShort()
    }
    val t = AudioTrack(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
        AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build(),
        data.size * 2, AudioTrack.MODE_STATIC, AudioManager.AUDIO_SESSION_ID_GENERATE
    )
    t.write(data, 0, n)
    t.play()
    delay(1100)
    t.release()
}
