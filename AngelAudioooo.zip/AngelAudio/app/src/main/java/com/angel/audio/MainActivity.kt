package com.angel.audio

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.*
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("angel", Context.MODE_PRIVATE)
        AudioState.load(prefs)
        setContent { AngelTheme { Surface(Modifier.fillMaxSize()) { AngelScreen(prefs) } } }
    }
}

@Composable
private fun orangeChip() =
    FilterChipDefaults.filterChipColors(selectedContainerColor = Orange, selectedLabelColor = Color.Black)

private fun startSpeaker(ctx: Context) =
    ContextCompat.startForegroundService(ctx, Intent(ctx, SpeakerService::class.java))

private fun stopSpeaker(ctx: Context) =
    ctx.startService(Intent(ctx, SpeakerService::class.java).setAction("STOP"))

/** IPv4 addresses of this phone; USB-tether ones first because the computer reaches the phone there. */
private fun phoneAddresses(): List<String> = try {
    val all = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().map { ni.name to (it.hostAddress ?: "") } }
        .filter { it.second.isNotEmpty() }
    val usb = all.filter { n -> listOf("rndis", "usb", "ncm", "eth").any { n.first.startsWith(it) } }
    (usb + (all - usb.toSet())).map { it.second }
} catch (_: Exception) { emptyList() }

@SuppressLint("MissingPermission")
private fun pairedDevices(ctx: Context): List<Pair<String, String>> = try {
    if (!btAllowed(ctx)) emptyList()
    else (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bondedDevices.orEmpty()
        .map { (it.name ?: it.address) to it.address }.sortedBy { it.first.lowercase() }
} catch (_: Exception) { emptyList() }

@SuppressLint("MissingPermission")
private fun myBluetoothName(ctx: Context): String = try {
    if (btAllowed(ctx)) (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.name ?: Build.MODEL
    else Build.MODEL
} catch (_: Exception) { Build.MODEL }

private fun openTetherSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        ctx.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun openBluetoothSettings(ctx: Context) =
    ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

private fun makeVisible(ctx: Context) = try {
    ctx.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
        .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (_: Exception) { openBluetoothSettings(ctx) }

private fun ago(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return when {
        s < 60 -> "${s}s"
        s < 3600 -> "${s / 60} min"
        s < 86400 -> "${s / 3600} h ${(s % 3600) / 60} min"
        else -> "${s / 86400} days"
    }
}

private fun openMap(ctx: Context, t: Tracked) = try {
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${t.lat},${t.lon}?q=${t.lat},${t.lon}(${Uri.encode(t.name)})"))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (_: Exception) {}

/** What the join code says: main phone's name, its network addresses, its Bluetooth name. */
private fun joinText(model: String, ips: List<String>, btName: String) =
    "ANGELAUDIO1|$model|${ips.joinToString(",")}|$btName"

private class Join(val model: String, val ips: List<String>, val btName: String)

private fun parseJoin(raw: String?): Join? {
    val p = raw?.split("|") ?: return null
    if (p.size < 4 || p[0] != "ANGELAUDIO1") return null
    return Join(p[1], p[2].split(",").filter { it.isNotBlank() }, p[3])
}

private fun sameNetwork(a: List<String>, b: List<String>) =
    a.any { x -> b.any { y -> x.substringBeforeLast('.') == y.substringBeforeLast('.') } }

@Composable
private fun Section(number: Int, title: String, hint: String? = null) {
    Column {
        Text("$number  $title", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        if (hint != null) Text(hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChoiceCard(selected: Boolean, enabled: Boolean, title: String, body: String, onClick: () -> Unit) {
    Card(
        onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) Color(0xFF3A1D00) else Graphite,
            disabledContainerColor = if (selected) Color(0xFF3A1D00) else Graphite,
            contentColor = Color.White, disabledContentColor = Color(0xFFBBBBBB)
        ),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Orange else Color(0xFF333333))
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun QrCode(text: String) {
    val matrix = remember(text) { try { QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0) } catch (_: Exception) { null } }
    Box(Modifier.size(220.dp).background(Color.White, RoundedCornerShape(12.dp)).padding(10.dp)) {
        if (matrix != null) Canvas(Modifier.fillMaxSize()) {
            val cell = this.size.width / matrix.width
            for (y in 0 until matrix.height) for (x in 0 until matrix.width)
                if (matrix[x, y]) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
        }
    }
}

/** One nearby phone on the main phone's screen: where it plays, plus a button to find out which phone it is. */
@Composable
private fun PhoneRow(p: PhoneInfo, scope: CoroutineScope, onPlace: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text(p.via, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                OutlinedButton(onClick = { open = true }) { Text(POSITIONS[p.pos.coerceIn(0, 7)] + " ▾") }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    listOf(0, 1, 2, 3, 4, 5, 6, 7).forEach { i ->
                        DropdownMenuItem(text = { Text(POSITIONS[i]) }, onClick = { open = false; onPlace(i) })
                    }
                }
            }
            Spacer(Modifier.width(6.dp))
            TextButton(onClick = { scope.launch { AudioState.beep.emit(p.id) } }) { Text("Beep") }
        }
    }
}

/** A phone that shared its position: last known place, battery, and a way to make it ring. */
@Composable
private fun TrackedRow(t: Tracked, now: Long, connected: Boolean, ringing: Boolean,
                       onMap: () -> Unit, onRing: () -> Unit, onForget: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(if (connected) Orange else Color(0xFF666666), CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(t.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (t.battery >= 0) Text("${t.battery}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (connected) "Connected now" else "Not connected. Last heard ${ago(now - t.heardMs)} ago",
                style = MaterialTheme.typography.bodyMedium)
            Text("Last position ${ago(now - t.fixMs)} ago, within about ${t.acc.roundToInt()} m",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onMap) { Text("Show on map") }
                Button(onClick = onRing) { Text(if (ringing) "Stop ringing" else if (connected) "Ring it" else "Ring when found") }
                TextButton(onClick = onForget) { Text("Forget") }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AngelScreen(prefs: SharedPreferences) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val running by AudioState.running.collectAsState()
    val status by AudioState.status.collectAsState()
    val pos by AudioState.position.collectAsState()
    val gain by AudioState.gainPercent.collectAsState()
    val fine by AudioState.fineTuneMs.collectAsState()
    val hub by AudioState.hubMode.collectAsState()
    val connected by AudioState.pcConnected.collectAsState()
    val warning by AudioState.warning.collectAsState()
    val transport by AudioState.transport.collectAsState()
    val btAddr by AudioState.btHubAddr.collectAsState()
    val nearby by AudioState.nearby.collectAsState()
    val pendingBt by AudioState.pendingBt.collectAsState()
    val assigned by AudioState.assignedPos.collectAsState()
    val tracked by AudioState.tracked.collectAsState()
    val connectedIds by AudioState.connectedDevIds.collectAsState()
    val wanted by AudioState.ringWanted.collectAsState()
    val share by AudioState.shareLocation.collectAsState()
    val ringing by AudioState.ringing.collectAsState()
    val fix by AudioState.lastFix.collectAsState()

    var addresses by remember { mutableStateOf(phoneAddresses()) }
    var paired by remember { mutableStateOf(pairedDevices(ctx)) }
    var found by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var searching by remember { mutableStateOf(false) }
    var afterPerms by remember { mutableStateOf<(() -> Unit)?>(null) }
    var scanMessage by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    var showConsent by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            addresses = withContext(Dispatchers.IO) { phoneAddresses() }
            paired = withContext(Dispatchers.IO) { pairedDevices(ctx) }
            now = System.currentTimeMillis()
            delay(2000)
        }
    }

    // ---- permissions: ask only for what the next action needs, then do it
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        afterPerms?.invoke(); afterPerms = null
    }
    fun withPerms(list: List<String>, then: () -> Unit) {
        val missing = list.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) then() else { afterPerms = then; permLauncher.launch(missing.toTypedArray()) }
    }
    fun startPerms() = buildList {
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        if (!AudioState.hubMode.value && AudioState.shareLocation.value) {
            add(Manifest.permission.ACCESS_FINE_LOCATION); add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }
    fun searchPerms() = buildList {
        if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_CONNECT) }
        else add(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    fun save(block: SharedPreferences.Editor.() -> Unit) = prefs.edit().apply(block).apply()
    fun begin() = withPerms(startPerms()) { startSpeaker(ctx) }
    // An extra phone is asked once, in plain words, before it ever shares its location.
    fun start() { if (!AudioState.hubMode.value && !AudioState.shareAsked.value) showConsent = true else begin() }
    fun answerConsent(yes: Boolean) {
        showConsent = false
        AudioState.shareLocation.value = yes; AudioState.shareAsked.value = true
        save { putBoolean("share", yes); putBoolean("shareasked", true) }
        begin()
    }
    fun chooseHub(name: String, addr: String) {
        AudioState.btHubAddr.value = addr; AudioState.btHubName.value = name
        save { putString("btaddr", addr); putString("btname", name) }
    }

    // ---- Bluetooth search for nearby phones (no pairing needed)
    DisposableEffect(searching) {
        if (!searching) return@DisposableEffect onDispose { }
        val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.action != BluetoothDevice.ACTION_FOUND) return
                val d = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        else @Suppress("DEPRECATION") i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                val name = i.getStringExtra(BluetoothDevice.EXTRA_NAME) ?: try { d?.name } catch (_: SecurityException) { null }
                if (d != null && !name.isNullOrEmpty()) found = found.filter { it.second != d.address } + (name to d.address)
            }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(BluetoothDevice.ACTION_FOUND), ContextCompat.RECEIVER_EXPORTED)
        try { adapter?.startDiscovery() } catch (_: SecurityException) {}
        onDispose {
            try { adapter?.cancelDiscovery() } catch (_: Exception) {}
            try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }
    LaunchedEffect(searching) { if (searching) { delay(15000); searching = false } }

    // ---- after scanning a join code over Bluetooth: pick the main phone as soon as it shows up
    LaunchedEffect(pendingBt, paired, found) {
        if (pendingBt.isEmpty()) return@LaunchedEffect
        val hit = (paired + found).firstOrNull { it.first.equals(pendingBt, ignoreCase = true) }
        if (hit != null) { chooseHub(hit.first, hit.second); AudioState.pendingBt.value = ""; searching = false }
        else if (!searching) withPerms(searchPerms()) { found = emptyList(); searching = true }
    }

    // ---- scan a join code
    fun handleJoin(raw: String?) {
        val j = parseJoin(raw)
        if (j == null) { scanMessage = "That code is not from Angel Audio."; return }
        AudioState.hubMode.value = false; save { putBoolean("hub", false) }
        AudioState.position.value = 8; save { putInt("pos", 8) }
        AudioState.hubIps.value = j.ips; AudioState.hubName.value = j.model
        if (sameNetwork(addresses, j.ips)) {
            AudioState.transport.value = 0; save { putInt("transport", 0) }
            scanMessage = "Found ${j.model} on your Wi-Fi."
        } else {
            AudioState.transport.value = 1; save { putInt("transport", 1) }
            AudioState.btHubAddr.value = ""; AudioState.pendingBt.value = j.btName.ifEmpty { j.model }
            scanMessage = "Looking for ${j.model} over Bluetooth. Ask its owner to tap 'Make visible' if it takes long."
        }
        if (!running) start()
    }
    fun scanCode() {
        val options = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(ctx, options).startScan()
            .addOnSuccessListener { handleJoin(it.rawValue) }
            .addOnFailureListener { scanMessage = "Could not open the scanner. Choose the main phone from the list instead." }
    }

    if (showConsent) AlertDialog(
        onDismissRequest = { },
        title = { Text("Find this phone if it gets lost?") },
        text = {
            Text("While this phone is connected to the main phone, it can share its location, battery level and name with the main phone only. " +
                    "Then the main phone can show where it was last seen and make it ring loudly. " +
                    "You can turn this off any time under 'Find my phone', and it stops when you tap Stop.")
        },
        confirmButton = { Button(onClick = { answerConsent(true) }) { Text("Share") } },
        dismissButton = { TextButton(onClick = { answerConsent(false) }) { Text("Not now") } }
    )

    val canStart = running || hub || transport == 0 || btAddr.isNotEmpty() || pendingBt.isNotEmpty()

    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            Surface(color = Color.Black) {
                Button(
                    enabled = canStart,
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(60.dp),
                    onClick = { if (running) stopSpeaker(ctx) else start() }
                ) {
                    Text(
                        when { running -> "Stop"; canStart -> "Start"; else -> "Choose the main phone first" },
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Column {
                Text("Angel Audio", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = Orange)
                Text("Turn phones into speakers for your computer.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).background(if (connected) Orange else Color(0xFF666666), CircleShape))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(status, style = MaterialTheme.typography.titleMedium)
                        if (!hub && assigned in 0..7) Text("The main phone placed this phone as ${POSITIONS[assigned]}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (warning.isNotEmpty()) Text(warning, color = Orange, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (ringing) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1D00)),
                border = BorderStroke(2.dp, Orange)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This phone is ringing", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("The main phone is looking for it.")
                    Button(onClick = { Ringer.stopByOwner() }) { Text("Stop ringing") }
                }
            }

            // 1 --------------------------------------------------------------
            Section(1, "What will this phone do?", if (running) "Tap Stop to change this." else null)
            ChoiceCard(hub, !running, "Main phone",
                "Plugged into my computer. It sets up the computer, finds the other phones and places them.") {
                AudioState.hubMode.value = true; save { putBoolean("hub", true) }
                if (AudioState.position.value == 8) { AudioState.position.value = 7; save { putInt("pos", 7) } }
            }
            ChoiceCard(!hub, !running, "Extra speaker",
                "Joins the main phone by scanning its code or finding it nearby.") {
                AudioState.hubMode.value = false; save { putBoolean("hub", false) }
                if (AudioState.position.value == 7) { AudioState.position.value = 8; save { putInt("pos", 8) } }
            }

            // 2 --------------------------------------------------------------
            if (hub) {
                Section(2, "Connect to the computer")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Do these in order:", fontWeight = FontWeight.Bold)
                        Text("a. Tap Start (bottom of the screen).")
                        Text("b. Plug this phone into the computer with a USB cable and turn on USB tethering.")
                        OutlinedButton(onClick = { openTetherSettings(ctx) }) { Text("Open USB tethering settings") }
                        Text("c. On the computer, open a web browser and go to:")
                        if (addresses.isEmpty()) Text("(waiting for a network)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        addresses.forEach { Text("http://$it:8080", fontWeight = FontWeight.Bold, color = Orange) }
                        Text("d. Press Download, open the file, and follow the window. Next time just use the Angel Audio shortcut on the desktop.")
                    }
                }

                Section(3, "Add other phones", "On each other phone choose Extra speaker, then Scan code. Or let them find this phone by themselves.")
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        QrCode(joinText(Build.MODEL, addresses, myBluetoothName(ctx)))
                        Text("Scan this with the other phone", style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = {
                            withPerms(if (Build.VERSION.SDK_INT >= 31) listOf(Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT) else emptyList()) { makeVisible(ctx) }
                        }) { Text("Make visible to Bluetooth phones (2 min)") }
                    }
                }

                Section(4, "Phones nearby", "They appear here by themselves. Choose where each one plays; tap Beep to see which phone is which.")
                if (nearby.isEmpty()) Text(if (running) "Searching… no phones yet." else "Tap Start to begin searching.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                nearby.forEach { p ->
                    PhoneRow(p, scope) { newPos ->
                        AudioState.assignments.value = AudioState.assignments.value + (p.id to newPos)
                        AudioState.assignReported.value = AudioState.assignReported.value + (p.id to p.reported)
                    }
                }

                Section(5, "Find a lost phone", "Phones that joined with 'Find my phone' on show their last known position here. It only works for phones that agreed.")
                if (tracked.isEmpty()) Text("None yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                tracked.values.sortedByDescending { it.heardMs }.forEach { tr ->
                    val isOn = tr.devId in wanted
                    TrackedRow(tr, now, tr.devId in connectedIds, isOn,
                        onMap = { openMap(ctx, tr) },
                        onRing = { AudioState.ringWanted.value = if (isOn) wanted - tr.devId else wanted + tr.devId },
                        onForget = {
                            AudioState.tracked.value = AudioState.tracked.value - tr.devId
                            AudioState.ringWanted.value = AudioState.ringWanted.value - tr.devId
                            save { putString("track", AudioState.serializeTracked(AudioState.tracked.value)) }
                        })
                }
                Text("Needs the phone to be on and connected or in range. For a phone far away use Google Find Hub (Android) or Find My (iPhone). Forget removes it until it joins again.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Section(2, "Join the main phone")
                Button(modifier = Modifier.fillMaxWidth().height(56.dp), onClick = { scanCode() }) {
                    Text("Scan the main phone's code", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                if (scanMessage.isNotEmpty()) Text(scanMessage, color = Orange, style = MaterialTheme.typography.bodyMedium)
                Text("Or choose how to connect:", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = transport == 0, enabled = !running, colors = orangeChip(),
                        onClick = { AudioState.transport.value = 0; save { putInt("transport", 0) } }, label = { Text("Wi-Fi (best)") })
                    FilterChip(selected = transport == 1, enabled = !running, colors = orangeChip(),
                        onClick = { AudioState.transport.value = 1; save { putInt("transport", 1) } }, label = { Text("Bluetooth") })
                }
                if (transport == 0) {
                    val hubName by AudioState.hubName.collectAsState()
                    Text(
                        if (hubName.isNotEmpty()) "Main phone found: $hubName. Tap Start." else "Put this phone on the same Wi-Fi as the main phone. It finds it by itself.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    OutlinedButton(enabled = !running, onClick = {
                        withPerms(searchPerms()) { found = emptyList(); searching = true }
                    }) { Text(if (searching) "Searching…" else "Search for nearby phones") }
                    Text("On the main phone tap 'Make visible' so it can be found.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    (found + paired.filter { p -> found.none { it.second == p.second } }).forEach { (name, addr) ->
                        ChoiceCard(btAddr == addr, !running, name, if (btAddr == addr) "Selected as the main phone" else "Tap to choose") {
                            chooseHub(name, addr)
                        }
                    }
                    if (found.isEmpty() && paired.isEmpty() && !searching) Text("Nothing found yet. Tap Search.",
                        style = MaterialTheme.typography.bodySmall, color = Orange)
                    OutlinedButton(onClick = { openBluetoothSettings(ctx) }) { Text("Open Bluetooth settings") }
                    Text("Bluetooth works for a few phones and adds a little delay. Wi-Fi is better for 4 or more.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (!hub) {
                Section(4, "Find my phone", "Lets the main phone show where this phone was last seen and make it ring if it gets lost.")
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Share location with the main phone", fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    !share -> "Off. The main phone can't find this phone."
                                    fix != null -> "On. Last position shared ${ago(now - fix!!.timeMs)} ago."
                                    else -> "On. Waiting for a location fix…"
                                },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(checked = share, onCheckedChange = { on ->
                            AudioState.shareLocation.value = on; AudioState.shareAsked.value = true
                            save { putBoolean("share", on); putBoolean("shareasked", true) }
                            if (on) withPerms(listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) {}
                        })
                    }
                }
            }

            // speaker position ----------------------------------------------------
            Section(if (hub) 6 else 3, if (hub) "Which speaker is this phone?" else "Which speaker should this phone be?",
                if (hub) "Only one phone? Choose Solo and it plays everything."
                else "Leave it on Auto and the main phone decides.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                (if (hub) listOf(7, 0, 2, 1, 3, 4, 5, 6) else listOf(8, 7, 0, 2, 1, 3, 4, 5, 6)).forEach { i ->
                    FilterChip(
                        selected = pos == i, colors = orangeChip(),
                        onClick = { AudioState.position.value = i; save { putInt("pos", i) } },
                        label = { Text(POSITIONS[i]) }
                    )
                }
            }

            // sound ------------------------------------------------------------------
            Section(if (hub) 7 else 5, "Sound")
            Text("Volume: $gain%", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = gain.toFloat(),
                onValueChange = { AudioState.gainPercent.value = it.roundToInt() },
                onValueChangeFinished = { save { putInt("gain", AudioState.gainPercent.value) } },
                valueRange = 0f..200f,
                colors = SliderDefaults.colors(inactiveTrackColor = TrackGrey)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Normal" to 100, "Loud" to 150, "Max" to 200).forEach { (label, v) ->
                    FilterChip(selected = gain == v, colors = orangeChip(),
                        onClick = { AudioState.gainPercent.value = v; save { putInt("gain", v) } },
                        label = { Text("$label $v%") })
                }
            }
            if (gain > 100) Text(
                "Above 100% is boosted. It can sound harsh and strain small speakers, so keep it away from your ears.",
                color = Orange, style = MaterialTheme.typography.bodySmall
            )

            Text("Sync nudge: ${if (fine > 0) "+" else ""}$fine ms", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = fine.toFloat(),
                onValueChange = { AudioState.fineTuneMs.value = it.roundToInt() },
                onValueChangeFinished = { save { putInt("fine", AudioState.fineTuneMs.value) } },
                valueRange = -150f..150f,
                colors = SliderDefaults.colors(inactiveTrackColor = TrackGrey)
            )
            Text("If this phone sounds early or late next to the others, nudge it.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = { scope.launch { playTestTone(AudioState.gainPercent.value / 100f) } }
            ) { Text("Play a test sound on this phone") }
            Spacer(Modifier.height(8.dp))
        }
    }
}
