package com.angel.audio

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.net.wifi.WifiManager
import android.os.Build
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

private const val PORT_DISCOVERY = 49500
private const val PORT_AUDIO = 49501   // phone -> phone, and PC -> phone in direct mode
private const val PORT_SYNC = 49502    // clock sync
private const val PORT_HUB = 49503     // PC -> hub phone (one packet per channel)
private const val PORT_CTL = 49504      // main phone -> extra phone: "you are Front Left", "play a test sound"
private const val PORT_HUBBEACON = 49505 // main phone announces itself
private const val PORT_LOC = 49506      // extra phone -> main phone: shared position
private const val PORT_HTTP = 8080     // hub phone serves the PC installer here
private const val RATE = 48000
private const val LATENCY_US = 150_000L

private val LE = ByteOrder.LITTLE_ENDIAN

private class Peer(val ip: InetAddress, val name: String, var reported: Int, @Volatile var seen: Long) { @Volatile var pos = 7; @Volatile var devId = "" }

class SpeakerService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val queue = Channel<Pkt>(256, BufferOverflow.DROP_OLDEST)
    private val peers = ConcurrentHashMap<String, Peer>()
    private val btHub by lazy { BtHub(this, scope, { id, rep -> resolve(id, rep) }, { s -> parseLoc(s, "Bluetooth")?.let { recordTracked(it) } }) }
    private val ringingSent = HashSet<String>()
    private val knownHubs = ConcurrentHashMap<String, String>()   // ip -> name, heard from main-phone announcements
    private var wifiLock: WifiManager.WifiLock? = null
    private var cpuLock: PowerManager.WakeLock? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var started = false

    @Volatile private var offsetUs = 0L      // senderClock - localClock (speaker mode)
    @Volatile private var synced = false
    @Volatile private var senderIp: InetAddress? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // Always start from the saved settings, even if Android recreated this service on its own.
        AudioState.load(getSharedPreferences("angel", Context.MODE_PRIVATE))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        showNotification()
        if (!started) { started = true; begin() }
        return START_NOT_STICKY
    }

    private fun showNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("angel", "Angel Audio", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, SpeakerService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "angel")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("Angel Audio is running")
            .setContentText(when { AudioState.hubMode.value -> "Main phone: connected to your computer"; sharing() -> "Speaker. Sharing this phone's location with the main phone so it can be found"; else -> "This phone is a surround speaker" })
            .setContentIntent(open).addAction(0, "Stop", stop).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            // The location type is only added when the person allowed location, otherwise Android refuses to start.
            var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            if (locationAllowed() && sharing()) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            startForeground(1, n, types)
        } else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun begin() {
        Ringer.attach(this, scope)
        AudioState.running.value = true
        AudioState.pcConnected.value = false
        AudioState.status.value = "Waiting for your computer…"
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(
            if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF, "angelaudio").apply { acquire() }

        multicastLock = wm.createMulticastLock("angelaudio:bcast").apply { setReferenceCounted(false); acquire() }
        cpuLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "angelaudio:cpu")
            .apply { setReferenceCounted(false); acquire() }

        if (AudioState.hubMode.value) {
            scope.launch { guarded("Audio input") { hubIntake() } }
            scope.launch { guarded("Phone finder") { peerListener() } }
            scope.launch { guarded("Clock") { syncServer() } }
            scope.launch { guarded("Computer setup page") { httpServer() } }
            scope.launch { guarded("Bluetooth") { btHub.serve() } }
            scope.launch { guarded("Nearby phones") { nearbyLoop() } }
            scope.launch { guarded("Announcer") { hubBeacon() } }
            scope.launch { guarded("Test sounds") { beepRelay() } }
            scope.launch { guarded("Find my phone") { trackListener() } }
        } else if (AudioState.transport.value == 1) {
            scope.launch { guarded("Bluetooth") { BtPeer(this@SpeakerService, queue).run() } }
            scope.launch { guarded("Location") { locationLoop() } }
        } else {
            scope.launch { guarded("Location") { locationLoop() } }
            scope.launch { guarded("Main phone finder") { hubFinder() } }
            scope.launch { guarded("Messages") { controlListener() } }
            scope.launch { guarded("Announcer") { beacon() } }
            scope.launch { guarded("Clock sync") { syncLoop() } }
            scope.launch { guarded("Audio input") { speakerReceive() } }
        }
        scope.launch { guarded("Speaker") { playLoop() } }
    }

    /** A problem in one loop must never stop the others: log it, wait a little longer each time, try again. */
    private suspend fun guarded(name: String, block: suspend () -> Unit) {
        var fails = 0
        while (currentCoroutineContext().isActive) {
            try { block(); return } catch (e: CancellationException) { throw e }
            catch (e: Exception) {
                fails++
                val why = e.message?.takeIf { it.length in 3..60 } ?: "problem"
                AudioState.warning.value = "$name: $why. Retrying ($fails)"
                delay(min(1500L * fails, 8000L))
            }
        }
    }

    private fun bound(port: Int) = DatagramSocket(null as SocketAddress?).apply {
        reuseAddress = true; bind(InetSocketAddress(port)); soTimeout = 1000
        try { receiveBufferSize = 1 shl 20 } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- speaker mode
    private suspend fun beacon() {
        DatagramSocket().use { s ->
            s.broadcast = true
            while (currentCoroutineContext().isActive) {
                val m = "ANGELSPK|${Build.MODEL.replace('|', ' ')}|${AudioState.position.value}|${AudioState.devId.value}".toByteArray()
                val targets = listOf("255.255.255.255") + knownHubs.keys + AudioState.hubIps.value
                for (ip in targets.distinct()) {
                    try { s.send(DatagramPacket(m, m.size, InetAddress.getByName(ip), PORT_DISCOVERY)) } catch (_: Exception) {}
                }
                delay(1500)
            }
        }
    }

    private suspend fun syncLoop() {
        DatagramSocket().use { s ->
            s.soTimeout = 400
            while (currentCoroutineContext().isActive) {
                val ip = senderIp
                if (ip == null) { delay(500); continue }
                var bestRtt = Long.MAX_VALUE
                var bestOff = 0L
                repeat(8) {
                    try {
                        val t1 = nowUs()
                        val m = "T|$t1".toByteArray()
                        s.send(DatagramPacket(m, m.size, ip, PORT_SYNC))
                        val p = DatagramPacket(ByteArray(128), 128)
                        s.receive(p)
                        val t4 = nowUs()
                        val parts = String(p.data, 0, p.length).split("|")
                        if (parts.size == 3 && parts[0] == "R" && parts[1].toLong() == t1) {
                            val rtt = t4 - t1
                            if (rtt < bestRtt) { bestRtt = rtt; bestOff = parts[2].toLong() - (t1 + t4) / 2 }
                        }
                    } catch (_: Exception) {}
                    delay(40)
                }
                if (bestRtt != Long.MAX_VALUE) { offsetUs = bestOff; synced = true }
                delay(4000)
            }
        }
    }

    private suspend fun speakerReceive() {
        val buf = ByteArray(4096)
        val pkt = DatagramPacket(buf, buf.size)
        bound(PORT_AUDIO).use { sock ->
            while (currentCoroutineContext().isActive) {
                pkt.length = buf.size                         // reset, or a short packet shrinks the next read
                try { sock.receive(pkt) } catch (_: SocketTimeoutException) {
                    AudioState.pcConnected.value = false
                    AudioState.status.value = "Waiting for your computer or hub phone…"
                    continue
                }
                senderIp = pkt.address
                if (!synced) { AudioState.status.value = "Syncing clocks…"; continue }
                if (pkt.length < 14) continue
                val bb = ByteBuffer.wrap(buf, 0, pkt.length).order(LE)
                val seq = bb.int.toLong() and 0xFFFFFFFFL
                val sendUs = bb.long
                val n = bb.short.toInt() and 0xFFFF
                if (pkt.length < 14 + 2 * n) continue
                val s = ShortArray(n) { bb.short }
                AudioState.pcConnected.value = true
                AudioState.warning.value = ""
                AudioState.status.value = "Playing as ${AudioState.shownName()}"
                queue.trySend(Pkt(seq, sendUs - offsetUs, s))
            }
        }
    }

    // ---------------------------------------------------------------- hub mode
    /** Receives per-channel packets from the PC, plays ours, relays the rest to Wi-Fi and Bluetooth phones. */
    private suspend fun hubIntake() {
        val buf = ByteArray(4096)
        val pkt = DatagramPacket(buf, buf.size)
        DatagramSocket().use { out -> bound(PORT_HUB).use { sock ->
            while (currentCoroutineContext().isActive) {
                pkt.length = buf.size
                try { sock.receive(pkt) } catch (_: SocketTimeoutException) {
                    AudioState.pcConnected.value = false
                    AudioState.status.value = "Waiting for your computer…"
                    continue
                }
                if (pkt.length < 15) continue
                val bb = ByteBuffer.wrap(buf, 0, pkt.length).order(LE)
                val seq = bb.int.toLong() and 0xFFFFFFFFL
                val t0 = bb.long                  // already in THIS phone's clock (PC corrects for it)
                val n = bb.short.toInt() and 0xFFFF
                val ch = bb.get().toInt()
                if (pkt.length < 15 + 2 * n) continue
                // Bluetooth phones need more buffering, so everyone waits a little longer while one is connected.
                val t = t0 + if (btHub.count() > 0) 200_000L else 0L

                val now = System.currentTimeMillis()
                for ((key, p) in peers) {
                    if (now - p.seen > 6000) { peers.remove(key); continue }
                    if (p.pos != ch) continue
                    val b = ByteBuffer.allocate(14 + 2 * n).order(LE)
                    b.putInt(seq.toInt()); b.putLong(t); b.putShort(n.toShort()); b.put(buf, 15, 2 * n)
                    try { out.send(DatagramPacket(b.array(), b.capacity(), p.ip, PORT_AUDIO)) } catch (_: Exception) {}
                }
                val mine = ch == AudioState.position.value
                if (mine || btHub.hasPos(ch)) {
                    val s = ShortArray(n) { bb.short }
                    if (mine) queue.trySend(Pkt(seq, t, s))
                    btHub.sendAudio(ch, seq, t, s)
                }
                val others = peers.size + btHub.count()
                AudioState.peers.value = others
                AudioState.pcConnected.value = true
                AudioState.warning.value = ""
                AudioState.status.value = "Playing as ${POSITIONS[AudioState.position.value]} · $others other phone(s)"
            }
        } }
    }

    private suspend fun peerListener() {
        val pkt = DatagramPacket(ByteArray(256), 256)
        bound(PORT_DISCOVERY).use { s ->
            while (currentCoroutineContext().isActive) {
                pkt.length = 256
                try { s.receive(pkt) } catch (_: SocketTimeoutException) { AudioState.peers.value = peers.size; continue }
                val p = String(pkt.data, 0, pkt.length).split("|")
                if (p.size >= 3 && p[0] == "ANGELSPK") {
                    val pos = p[2].toIntOrNull() ?: continue
                    val key = pkt.address.hostAddress ?: continue
                    val known = peers[key]
                    val dev = p.getOrNull(3).orEmpty().take(64)
                    if (known != null) { known.reported = pos; known.seen = System.currentTimeMillis(); known.devId = dev }
                    else peers[key] = Peer(pkt.address, p[1].take(40), pos, System.currentTimeMillis()).also { it.pos = resolve(key, pos); it.devId = dev }
                }
            }
        }
    }

    /** Where should this phone play? The main phone's user can change it; otherwise a free spot is picked. */
    @Synchronized
    private fun resolve(id: String, reported: Int): Int {
        val a = AudioState.assignments.value[id]
        if (a != null && AudioState.assignReported.value[id] == reported) return a
        val p = if (reported in 0..7) reported else nextFree()
        AudioState.assignments.value = AudioState.assignments.value + (id to p)
        AudioState.assignReported.value = AudioState.assignReported.value + (id to reported)
        return p
    }

    private fun nextFree(): Int {
        val used = HashSet<Int>()
        used.add(AudioState.position.value)
        val now = System.currentTimeMillis()
        peers.values.forEach { if (now - it.seen < 6000) used.add(it.pos) }
        used.addAll(btHub.positions())
        return (0..6).firstOrNull { it !in used } ?: 7
    }

    /** Keeps the "phones nearby" list fresh and tells each Wi-Fi phone where it plays. */
    private suspend fun nearbyLoop() {
        var tick = 0
        DatagramSocket().use { ctl ->
            while (currentCoroutineContext().isActive) {
                val now = System.currentTimeMillis()
                val list = ArrayList<PhoneInfo>()
                for ((key, p) in peers) {
                    if (now - p.seen > 6000) { peers.remove(key); continue }
                    p.pos = resolve(key, p.reported)
                    val m = "POS|${p.pos}|${Build.MODEL}".toByteArray()
                    try { ctl.send(DatagramPacket(m, m.size, p.ip, PORT_CTL)) } catch (_: Exception) {}
                    list += PhoneInfo(key, p.name, "Wi-Fi", p.pos, p.reported, p.devId)
                }
                btHub.refresh()
                list += btHub.infos()
                AudioState.nearby.value = list.sortedBy { it.name.lowercase() }

                // "Find my phone": ring the phones the owner asked for, every 3 seconds while wanted
                val wanted = AudioState.ringWanted.value
                val connected = HashSet<String>()
                for (ph in list) {
                    if (ph.devId.isEmpty()) continue
                    connected += ph.devId
                    if (ph.devId in wanted) {
                        if (tick % 3 == 0) { sendRing(ctl, ph, true); ringingSent += ph.devId }
                    } else if (ph.devId in ringingSent) { sendRing(ctl, ph, false); ringingSent -= ph.devId }
                }
                AudioState.connectedDevIds.value = connected
                tick++
                delay(1000)
            }
        }
    }

    private suspend fun hubBeacon() {
        DatagramSocket().use { s ->
            s.broadcast = true
            while (currentCoroutineContext().isActive) {
                val m = "ANGELHUB|${Build.MODEL}".toByteArray()
                try { s.send(DatagramPacket(m, m.size, InetAddress.getByName("255.255.255.255"), PORT_HUBBEACON)) } catch (_: Exception) {}
                delay(1500)
            }
        }
    }

    /** "Play a test sound on that phone" requests from the main phone's screen. */
    private suspend fun beepRelay() {
        DatagramSocket().use { s ->
            AudioState.beep.collect { id ->
                val p = peers[id]
                if (p != null) {
                    val m = "BEEP".toByteArray()
                    try { s.send(DatagramPacket(m, m.size, p.ip, PORT_CTL)) } catch (_: Exception) {}
                } else btHub.sendBeep(id)
            }
        }
    }

    /** Extra phone: listens for the main phone's announcements. */
    private suspend fun hubFinder() {
        val pkt = DatagramPacket(ByteArray(256), 256)
        bound(PORT_HUBBEACON).use { s ->
            while (currentCoroutineContext().isActive) {
                pkt.length = 256
                try { s.receive(pkt) } catch (_: SocketTimeoutException) { continue }
                val p = String(pkt.data, 0, pkt.length).split("|")
                if (p.size == 2 && p[0] == "ANGELHUB") {
                    knownHubs[pkt.address.hostAddress ?: continue] = p[1]
                    AudioState.hubName.value = p[1]
                }
            }
        }
    }

    /** Extra phone: "you are Front Left" and "play a test sound" from the main phone. */
    private suspend fun controlListener() {
        val pkt = DatagramPacket(ByteArray(256), 256)
        bound(PORT_CTL).use { s ->
            while (currentCoroutineContext().isActive) {
                pkt.length = 256
                try { s.receive(pkt) } catch (_: SocketTimeoutException) { continue }
                val p = String(pkt.data, 0, pkt.length).split("|")
                val fromHub = (pkt.address.hostAddress ?: "") in knownHubs.keys || (pkt.address.hostAddress ?: "") in AudioState.hubIps.value
                if (p[0] == "POS" && p.size >= 2) p[1].toIntOrNull()?.let { AudioState.assignedPos.value = it }
                else if (p[0] == "BEEP") scope.launch { playTestTone(AudioState.gainPercent.value / 100f) }
                else if (p[0] == "RING" && fromHub) Ringer.ring()         // only the main phone may ring this phone
                else if (p[0] == "STOPRING" && fromHub) Ringer.stop()
            }
        }
    }

    private fun sendRing(ctl: DatagramSocket, ph: PhoneInfo, on: Boolean) {
        if (ph.via == "Bluetooth") { btHub.sendRing(ph.id, on); return }
        val ip = peers[ph.id]?.ip ?: return
        val m = (if (on) "RING" else "STOPRING").toByteArray()
        try { repeat(if (on) 1 else 2) { ctl.send(DatagramPacket(m, m.size, ip, PORT_CTL)) } } catch (_: Exception) {}
    }

    @Synchronized
    private fun recordTracked(t: Tracked) {
        val map = AudioState.tracked.value + (t.devId to t)
        AudioState.tracked.value = map
        getSharedPreferences("angel", Context.MODE_PRIVATE).edit().putString("track", AudioState.serializeTracked(map)).apply()
    }

    /** Main phone: positions shared by extra phones over Wi-Fi. */
    private suspend fun trackListener() {
        val buf = ByteArray(1024)
        val pkt = DatagramPacket(buf, buf.size)
        bound(PORT_LOC).use { s ->
            while (currentCoroutineContext().isActive) {
                pkt.length = buf.size
                try { s.receive(pkt) } catch (_: SocketTimeoutException) { continue }
                val text = String(buf, 0, pkt.length)
                if (text.startsWith("LOC|")) parseLoc(text.removePrefix("LOC|"), "Wi-Fi")?.let { recordTracked(it) }
            }
        }
    }

    private fun locationAllowed() =
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun sharing() = !AudioState.hubMode.value && AudioState.shareLocation.value

    /** Extra phone: keeps a recent position and shares it with the main phone, only while the owner has it switched on. */
    @SuppressLint("MissingPermission")
    private suspend fun locationLoop() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(loc: Location) {
                AudioState.lastFix.value = Fix(loc.latitude, loc.longitude, loc.accuracy, System.currentTimeMillis())
            }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        var registered = false
        DatagramSocket().use { udp ->
            try {
                while (currentCoroutineContext().isActive) {
                    val on = sharing() && locationAllowed()
                    if (on && !registered) {
                        for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                            if (lm.isProviderEnabled(prov)) {
                                lm.requestLocationUpdates(prov, 15_000L, 0f, listener, Looper.getMainLooper())
                                lm.getLastKnownLocation(prov)?.let { listener.onLocationChanged(it) }
                            }
                        }
                        registered = true
                    } else if (!on && registered) {
                        lm.removeUpdates(listener); registered = false; AudioState.lastFix.value = null
                    }
                    if (on && AudioState.transport.value == 0) {
                        locPayload(this@SpeakerService)?.let { body ->
                            val m = "LOC|$body".toByteArray()
                            val targets = (knownHubs.keys + AudioState.hubIps.value + listOfNotNull(senderIp?.hostAddress)).distinct()
                            for (ip in targets) {
                                try { udp.send(DatagramPacket(m, m.size, InetAddress.getByName(ip), PORT_LOC)) } catch (_: Exception) {}
                            }
                        }
                    }
                    delay(15_000)
                }
            } finally { lm.removeUpdates(listener) }
        }
    }

    /** Answers clock pings from the PC and from other phones with this phone's clock. */
    private suspend fun syncServer() {
        val buf = ByteArray(128)
        val pkt = DatagramPacket(buf, buf.size)
        bound(PORT_SYNC).use { s ->
            while (currentCoroutineContext().isActive) {
                pkt.length = buf.size
                try { s.receive(pkt) } catch (_: SocketTimeoutException) { continue }
                val parts = String(buf, 0, pkt.length).split("|")
                if (parts.size == 2 && parts[0] == "T") {
                    val r = "R|${parts[1]}|${nowUs()}".toByteArray()
                    s.send(DatagramPacket(r, r.size, pkt.socketAddress))
                }
            }
        }
    }

    /** Tiny web server so the computer can download and install the PC program over the USB cable. */
    private suspend fun httpServer() {
        val ss = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT_HTTP)); soTimeout = 1000 }
        ss.use {
            while (currentCoroutineContext().isActive) {
                val c = try { ss.accept() } catch (_: SocketTimeoutException) { continue }
                scope.launch { try { handleHttp(c) } catch (_: Exception) {} }
            }
        }
    }

    private fun asset(name: String, hubIp: String) =
        assets.open(name).bufferedReader().use { it.readText() }.replace("__HUB_IP__", hubIp)

    private fun handleHttp(c: Socket) { c.use {
        c.soTimeout = 3000
        val r = c.getInputStream().bufferedReader()
        val first = r.readLine() ?: return@use
        while (true) { val l = r.readLine(); if (l.isNullOrEmpty()) break }
        val path = first.split(" ").getOrElse(1) { "/" }.substringBefore("?")
        val ip = c.localAddress.hostAddress ?: ""
        var mime = "text/plain; charset=utf-8"
        var download: String? = null
        val body: String? = when (path) {
            "/", "/index.html" -> { mime = "text/html; charset=utf-8"; asset("index.html", ip) }
            "/AngelAudioSetup.bat" -> {
                download = "AngelAudioSetup.bat"; mime = "application/octet-stream"
                asset("install.bat", ip).replace("\r\n", "\n").replace("\n", "\r\n")
            }
            "/install.sh" -> asset("install.sh", ip)
            "/angel_audio_sender.py" -> asset("angel_audio_sender.py", ip)
            else -> null
        }
        val out = c.getOutputStream()
        if (body == null) {
            out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
        } else {
            val bytes = body.toByteArray()
            val h = "HTTP/1.1 200 OK\r\nContent-Type: $mime\r\nContent-Length: ${bytes.size}\r\n" +
                    (download?.let { "Content-Disposition: attachment; filename=\"$it\"\r\n" } ?: "") +
                    "Connection: close\r\n\r\n"
            out.write(h.toByteArray()); out.write(bytes)
        }
        out.flush()
    } }

    // ---------------------------------------------------------------- playback (both modes)
    private suspend fun playLoop() {
        val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(max(minBuf * 4, 96_000))
            .build()
        var expected = -1L
        var lastFine = AudioState.fineTuneMs.value
        var lastUnderruns = 0
        track.play()
        try {
            while (currentCoroutineContext().isActive) {
                val p = withTimeoutOrNull(1000) { queue.receive() }
                if (p == null) { expected = -1; continue }
                var samples = p.samples
                val n = samples.size
                val fine = AudioState.fineTuneMs.value
                val underruns = if (Build.VERSION.SDK_INT >= 24) track.underrunCount else 0
                val ageUs = nowUs() - p.refUs
                val needAlign = expected < 0 || p.seq < expected || p.seq - expected > 20 ||
                        fine != lastFine || underruns != lastUnderruns || ageUs > LATENCY_US + 250_000

                if (needAlign) {
                    lastFine = fine; lastUnderruns = underruns
                    track.pause(); track.flush(); track.play()
                    val waitUs = p.refUs + LATENCY_US + fine * 1000L - nowUs()
                    if (waitUs > 0) writeSilence(track, min(waitUs * RATE / 1_000_000, RATE.toLong()).toInt())
                    else samples = samples.copyOfRange(min((-waitUs * RATE / 1_000_000).toInt(), n), n)
                } else if (p.seq > expected) {
                    writeSilence(track, min((p.seq - expected) * n, RATE.toLong()).toInt())   // lost packets keep timing
                }
                expected = p.seq + 1
                val out = applyGain(samples, AudioState.gainPercent.value / 100f)
                if (track.write(out, 0, out.size) < 0) throw IllegalStateException("audio write failed")
            }
        } finally { track.release() }
    }

    private fun writeSilence(t: AudioTrack, count: Int) {
        var left = count
        val z = ShortArray(960)
        while (left > 0) { val c = min(left, z.size); if (t.write(z, 0, c) < 0) throw IllegalStateException("audio write failed"); left -= c }
    }

    private fun applyGain(s: ShortArray, gain: Float): ShortArray {
        val o = ShortArray(s.size)
        for (i in s.indices) {
            var v = s[i] / 32768f * gain
            if (gain > 1f) {                       // soft limiter: 200% boosts instead of harshly clipping
                val a = abs(v)
                if (a > 0.7f) v = sign(v) * (0.7f + 0.3f * tanh((a - 0.7f) / 0.3f))
            }
            o[i] = (v * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        }
        return o
    }

    override fun onDestroy() {
        scope.cancel()
        btHub.close()
        wifiLock?.let { if (it.isHeld) it.release() }
        cpuLock?.let { if (it.isHeld) it.release() }
        multicastLock?.let { if (it.isHeld) it.release() }
        AudioState.peers.value = 0
        AudioState.running.value = false
        AudioState.pcConnected.value = false
        AudioState.warning.value = ""
        Ringer.stop()
        AudioState.lastFix.value = null
        AudioState.connectedDevIds.value = emptySet()
        AudioState.assignedPos.value = -1
        AudioState.nearby.value = emptyList()
        AudioState.status.value = "Stopped"
        super.onDestroy()
    }
}
