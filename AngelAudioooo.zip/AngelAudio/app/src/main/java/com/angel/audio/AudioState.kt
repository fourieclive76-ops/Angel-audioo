package com.angel.audio

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

val POSITIONS = listOf(
    "Front Left", "Front Right", "Center",
    "Side Left", "Side Right", "Rear Left", "Rear Right",
    "Solo (everything)", "Auto (main phone decides)"
)

/** A phone the main phone can see. pos = where the main phone placed it, reported = what the phone asked for. */
data class PhoneInfo(val id: String, val name: String, val via: String, val pos: Int, val reported: Int, val devId: String = "")

/** A position an extra phone shared (only after it agreed). Times are on the main phone's clock. */
data class Tracked(
    val devId: String, val name: String, val lat: Double, val lon: Double, val acc: Float,
    val fixMs: Long, val heardMs: Long, val battery: Int, val via: String
)
data class Fix(val lat: Double, val lon: Double, val acc: Float, val timeMs: Long)

object AudioState {
    val running = MutableStateFlow(false)
    val status = MutableStateFlow("Tap Start to begin")
    val position = MutableStateFlow(7)
    val gainPercent = MutableStateFlow(100)   // 0..200
    val fineTuneMs = MutableStateFlow(0)      // -150..150
    val hubMode = MutableStateFlow(false)     // true = this phone is the one plugged into the computer
    val pcConnected = MutableStateFlow(false)
    val transport = MutableStateFlow(0)       // extra phones: 0 = Wi-Fi, 1 = Bluetooth
    val btHubAddr = MutableStateFlow("")      // chosen main phone (Bluetooth address)
    val btHubName = MutableStateFlow("")
    val hubIps = MutableStateFlow<List<String>>(emptyList())   // from the join code, for direct (non-broadcast) contact
    val hubName = MutableStateFlow("")                         // name of the main phone this extra phone found
    val assignedPos = MutableStateFlow(-1)                     // where the main phone placed this phone
    val nearby = MutableStateFlow<List<PhoneInfo>>(emptyList())
    val assignments = MutableStateFlow<Map<String, Int>>(emptyMap())
    val assignReported = MutableStateFlow<Map<String, Int>>(emptyMap())
    val beep = MutableSharedFlow<String>(extraBufferCapacity = 8)   // "play a test sound on that phone"
    val pendingBt = MutableStateFlow("")                       // Bluetooth name to look for after scanning a join code
    val devId = MutableStateFlow("")                           // random id of this phone, used by "Find my phone"
    val shareLocation = MutableStateFlow(false)                // extra phone: agreed to be found by the main phone
    val shareAsked = MutableStateFlow(false)
    val lastFix = MutableStateFlow<Fix?>(null)
    val tracked = MutableStateFlow<Map<String, Tracked>>(emptyMap())   // main phone: shared positions
    val ringWanted = MutableStateFlow<Set<String>>(emptySet())         // main phone: phones it wants to ring
    val ringing = MutableStateFlow(false)                      // this phone is ringing because the main phone asked
    val connectedDevIds = MutableStateFlow<Set<String>>(emptySet())
    val warning = MutableStateFlow("")        // small non-fatal problems, shown under the status
    val peers = MutableStateFlow(0)           // other phones this hub is feeding

    /** Single place that reads saved settings, so the service and the screen always agree. */
    fun load(p: SharedPreferences) {
        position.value = p.getInt("pos", 7).coerceIn(0, POSITIONS.size - 1)
        gainPercent.value = p.getInt("gain", 100).coerceIn(0, 200)
        fineTuneMs.value = p.getInt("fine", 0).coerceIn(-150, 150)
        hubMode.value = p.getBoolean("hub", false)
        transport.value = p.getInt("transport", 0).coerceIn(0, 1)
        shareLocation.value = p.getBoolean("share", false)
        shareAsked.value = p.getBoolean("shareasked", false)
        tracked.value = parseTracked(p.getString("track", "") ?: "")
        var id = p.getString("devid", null)
        if (id == null) { id = java.util.UUID.randomUUID().toString().replace("-", ""); p.edit().putString("devid", id).apply() }
        devId.value = id
        btHubAddr.value = p.getString("btaddr", "") ?: ""
        btHubName.value = p.getString("btname", "") ?: "" 
    }

    fun serializeTracked(m: Map<String, Tracked>) = m.values.joinToString("\n") {
        "${it.devId}|${it.name.replace('|', ' ')}|${it.lat}|${it.lon}|${it.acc}|${it.fixMs}|${it.heardMs}|${it.battery}|${it.via}"
    }

    fun parseTracked(s: String): Map<String, Tracked> = s.lines().mapNotNull { l ->
        val p = l.split("|")
        if (p.size < 9) null else try {
            Tracked(p[0], p[1], p[2].toDouble(), p[3].toDouble(), p[4].toFloat(), p[5].toLong(), p[6].toLong(), p[7].toInt(), p[8])
        } catch (_: Exception) { null }
    }.associateBy { it.devId }

    fun shownName(): String {
        val a = assignedPos.value
        return POSITIONS.getOrElse(if (a in 0..7) a else position.value) { "Auto" }
    }
}
